//
//  InputStack.swift
//  Calculator
//
//  Created by Shimon on 9/10/17.
//  Copyright © 2017 Objective-C Fundamentals. All rights reserved.
//

import Foundation

class InputStack {
    static let sharedInstance = InputStack()
  //  private init() {}  //no other class can use this
   var userInputSeries = [String]()
    
    
    
}
